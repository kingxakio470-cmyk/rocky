package com.vpnrocky.autoanswer;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;

/**
 * VPN ROCKY Auto Answer Service
 * Fast & smooth detection of Answer / Accept buttons on incoming call screens.
 */
public class AnswerAccessibilityService extends AccessibilityService {

    private long lastClickTime = 0L;
    private static final long COOLDOWN_MS = 650;          // Fast but safe
    private static final long DOUBLE_CHECK_DELAY = 180;   // Quick second attempt

    private final Handler handler = new Handler(Looper.getMainLooper());

    // High priority exact matches first
    private static final String[] EXACT_KEYWORDS = {
            "answer", "accept", "answer call", "accept call",
            "pick up", "receive", "উত্তর", "উত্তর দিন",
            "রিসিভ", "গ্রহণ", "কল গ্রহণ", "কল উত্তর"
    };

    // Partial matches (used only if exact fails)
    private static final String[] PARTIAL_KEYWORDS = {
            "answer", "accept", "উত্তর", "রিসিভ", "গ্রহণ"
    };

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_VIEW_FOCUSED) {
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastClickTime < COOLDOWN_MS) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        // First fast scan
        if (tryClickAnswer(root, true)) {
            lastClickTime = now;
            // Schedule a very quick second attempt (some UIs need it)
            handler.postDelayed(() -> {
                AccessibilityNodeInfo r2 = getRootInActiveWindow();
                if (r2 != null) tryClickAnswer(r2, false);
            }, DOUBLE_CHECK_DELAY);
            return;
        }

        // Fallback broader scan
        if (tryClickAnswer(root, false)) {
            lastClickTime = now;
        }
    }

    private boolean tryClickAnswer(AccessibilityNodeInfo node, boolean exactOnly) {
        if (node == null) return false;

        CharSequence textCs = node.getText();
        CharSequence descCs = node.getContentDescription();
        String text = textCs == null ? "" : textCs.toString().toLowerCase(Locale.ROOT).trim();
        String desc = descCs == null ? "" : descCs.toString().toLowerCase(Locale.ROOT).trim();
        String combined = (text + " " + desc).trim();

        boolean match = false;
        if (exactOnly) {
            for (String key : EXACT_KEYWORDS) {
                if (combined.equals(key) || text.equals(key) || desc.equals(key)) {
                    match = true;
                    break;
                }
            }
        } else {
            for (String key : PARTIAL_KEYWORDS) {
                if (combined.contains(key)) {
                    match = true;
                    break;
                }
            }
        }

        if (match) {
            // Prefer direct click
            if (node.isClickable() && node.isEnabled()) {
                if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
            // Try parent (common for icon+text buttons)
            AccessibilityNodeInfo parent = node.getParent();
            if (parent != null && parent.isClickable() && parent.isEnabled()) {
                if (parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
            // Try grandparent as last resort
            if (parent != null) {
                AccessibilityNodeInfo grand = parent.getParent();
                if (grand != null && grand.isClickable() && grand.isEnabled()) {
                    if (grand.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true;
                    }
                }
            }
        }

        // Recurse children
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null && tryClickAnswer(child, exactOnly)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onInterrupt() {
        // Required
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
