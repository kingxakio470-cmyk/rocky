package com.vpnrocky.autoanswer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    // Colors matching the HTML design
    private static final int BG_DARK       = 0xFF0F0C1A;
    private static final int CARD_BG       = 0xFF1A1625;
    private static final int CARD_BORDER   = 0xFF2A2438;
    private static final int ACCENT        = 0xFFFFD36A;
    private static final int WHITE         = 0xFFFFFFFF;
    private static final int SECONDARY     = 0xFFE5E0ED;
    private static final int MUTED         = 0xFF9B93A8;
    private static final int SUCCESS       = 0xFF4ADE80;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Root scroll
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG_DARK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(40), dp(22), dp(40));
        root.setBackgroundColor(BG_DARK);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        // ===== HEADER =====
        TextView logoIcon = new TextView(this);
        logoIcon.setText("⚡");
        logoIcon.setTextSize(42);
        logoIcon.setGravity(Gravity.CENTER);
        logoIcon.setPadding(0, 0, 0, dp(6));

        TextView title = new TextView(this);
        title.setText("VPN ROCKY");
        title.setTextColor(ACCENT);
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);

        TextView subtitle = new TextView(this);
        subtitle.setText("SMART AUTO ANSWER");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(4), 0, dp(28));
        subtitle.setLetterSpacing(0.12f);

        root.addView(logoIcon);
        root.addView(title);
        root.addView(subtitle);

        // ===== MAIN CARD =====
        LinearLayout mainCard = createCard();
        mainCard.setPadding(dp(20), dp(22), dp(20), dp(22));

        TextView cardTitle = new TextView(this);
        cardTitle.setText("Auto Answer Monitor");
        cardTitle.setTextColor(WHITE);
        cardTitle.setTextSize(18);
        cardTitle.setTypeface(Typeface.DEFAULT_BOLD);
        cardTitle.setPadding(0, 0, 0, dp(8));

        TextView cardDesc = new TextView(this);
        cardDesc.setText("স্ক্রিনে Answer / Accept / উত্তর বাটন দেখামাত্র স্বয়ংক্রিয়ভাবে চাপ দেয়।\nসার্ভিসটি সিস্টেম Accessibility Settings থেকে চালু করতে হয়।");
        cardDesc.setTextColor(SECONDARY);
        cardDesc.setTextSize(13.5f);
        cardDesc.setLineSpacing(dp(3), 1.15f);
        cardDesc.setPadding(0, 0, 0, dp(18));

        // Status row
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setPadding(0, 0, 0, dp(16));

        View statusDot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(MUTED);
        statusDot.setBackground(dotBg);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dotLp.setMarginEnd(dp(10));
        statusDot.setLayoutParams(dotLp);

        TextView statusText = new TextView(this);
        statusText.setText("সার্ভিস বন্ধ (Settings থেকে চালু করুন)");
        statusText.setTextColor(MUTED);
        statusText.setTextSize(13);

        statusRow.addView(statusDot);
        statusRow.addView(statusText);

        // Big yellow button
        Button openSettings = createYellowButton("Accessibility Settings খুলুন");
        openSettings.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                Toast.makeText(this, "VPN ROCKY Auto Answer চালু করুন", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Settings খোলা যায়নি", Toast.LENGTH_SHORT).show();
            }
        });

        // How to use box
        LinearLayout howBox = createDashedBox();
        howBox.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView howTitle = new TextView(this);
        howTitle.setText("কীভাবে চালু করবেন");
        howTitle.setTextColor(ACCENT);
        howTitle.setTextSize(13);
        howTitle.setTypeface(Typeface.DEFAULT_BOLD);
        howTitle.setPadding(0, 0, 0, dp(8));

        TextView howSteps = new TextView(this);
        howSteps.setText("১. উপরের হলুদ বাটনে চাপুন\n২. তালিকা থেকে VPN ROCKY Auto Answer খুঁজুন\n৩. সার্ভিসটি চালু করুন ও অনুমতি দিন\n৪. এখন থেকে Answer বাটন দেখামাত্র অটো ক্লিক হবে");
        howSteps.setTextColor(SECONDARY);
        howSteps.setTextSize(12.5f);
        howSteps.setLineSpacing(dp(2), 1.2f);

        howBox.addView(howTitle);
        howBox.addView(howSteps);

        mainCard.addView(cardTitle);
        mainCard.addView(cardDesc);
        mainCard.addView(statusRow);
        mainCard.addView(openSettings);
        mainCard.addView(spacer(dp(16)));
        mainCard.addView(howBox);

        root.addView(mainCard);
        root.addView(spacer(dp(18)));

        // ===== INFO CARD =====
        LinearLayout infoCard = createCard();
        infoCard.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView infoTitle = new TextView(this);
        infoTitle.setText("Android কল অটো-আনসার সম্পর্কে");
        infoTitle.setTextColor(WHITE);
        infoTitle.setTextSize(15);
        infoTitle.setTypeface(Typeface.DEFAULT_BOLD);
        infoTitle.setPadding(0, 0, 0, dp(10));

        TextView infoBody = new TextView(this);
        infoBody.setText("এই অ্যাপটি Accessibility Service ব্যবহার করে স্ক্রিনে ভেসে ওঠা Answer / Accept বাটন শনাক্ত করে চাপ দেয়।\n\n• WhatsApp, Messenger, Phone app ইত্যাদিতে কাজ করার চেষ্টা করে\n• বাটনের টেক্সট বা contentDescription দেখে শনাক্ত করে\n• কোনো অদৃশ্য ব্যাকগ্রাউন্ড সার্ভিস চালায় না\n• আপনার অনুমতি ছাড়া কখনো চালু হয় না\n\nসব ডিভাইস/অ্যাপ ভার্সনে ১০০% গ্যারান্টি নেই। UI পরিবর্তন হলে কাজ নাও করতে পারে।");
        infoBody.setTextColor(SECONDARY);
        infoBody.setTextSize(12.5f);
        infoBody.setLineSpacing(dp(2), 1.2f);

        infoCard.addView(infoTitle);
        infoCard.addView(infoBody);

        root.addView(infoCard);
        root.addView(spacer(dp(24)));

        // Footer
        TextView footer = new TextView(this);
        footer.setText("VPN ROCKY · Auto Answer v2.0 · Local only");
        footer.setTextColor(MUTED);
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);

        scroll.addView(root);
        setContentView(scroll);
    }

    // ---------- UI Helpers ----------

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD_BG);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), CARD_BORDER);
        card.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        card.setLayoutParams(lp);
        return card;
    }

    private LinearLayout createDashedBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF14111F);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF3A3350);
        box.setBackground(bg);
        return box;
    }

    private Button createYellowButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFF1A1200);
        btn.setTextSize(15);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setAllCaps(false);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ACCENT);
        bg.setCornerRadius(dp(14));
        btn.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(52));
        btn.setLayoutParams(lp);
        btn.setPadding(dp(12), 0, dp(12), 0);
        return btn;
    }

    private View spacer(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, height));
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
